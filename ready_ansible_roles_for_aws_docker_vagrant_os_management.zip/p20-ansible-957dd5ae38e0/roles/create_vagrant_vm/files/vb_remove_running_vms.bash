#!/usr/bin/env /bin/bash

# Virtual box. Stop and remove a running VM with the given VM name

vbm=$1
vm_name=$2

if [[ "$vbm" == "" || "$vm_name" == "" ]]; then
  exit 0
fi

vbm="/usr/local/bin/VBoxManage"

# Stop VM if running
running_vms=$($vbm list runningvms | grep $vm_name  | cut -d' ' -f2 | cut -c 2- | rev | cut -d' ' -f2 | cut -c 2- | rev)

for running_vm in $running_vms
do
  $vbm controlvm "$running_vm" poweroff
done

# Remove VM from Virtualbox 
for running_vm in $running_vms
do
  $vbm unregistervm "$running_vm" --delete
done

# Tell ansible everything is good
exit 0

