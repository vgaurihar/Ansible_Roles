#!/usr/bin/env bash

set -x

docker_config_dir="/home/ansible/.docker"
docker_config_path="${docker_config_dir}/config.json"

if [[ -e $docker_config_path ]]; then
  grep -q 'ecr-login' ~/.docker/config.json
  ecr_present=$?
  if [[ ${ecr_present} == 1 ]]; then
    backup_file="${docker_config_path}.backup"
    cp ${docker_config_path} ${backup_file}
    head --lines=-2 ${backup_file} > ${docker_config_path}
    cat <<ECR >>${docker_config_path}
	},
	"credsStore": "ecr-login"
}
ECR
  fi
else
  mkdir -p $docker_config_dir
  chown ansible:ansbile $docker_config_dir
  chmod 700 $docker_config_dir
  cat <<ECR > ${docker_config_path}
{
  "credsStore": "ecr-login"
}
ECR
  chown ansible:ansbile ${docker_config_path}
  chmod 600 ${docker_config_path}
fi


