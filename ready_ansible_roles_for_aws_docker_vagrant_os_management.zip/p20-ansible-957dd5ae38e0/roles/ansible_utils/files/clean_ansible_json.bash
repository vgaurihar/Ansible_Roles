#!/usr/bin/env bash

input_file=$1

path=$(dirname "$input_file")
filename=$(basename -- "$input_file")
extension="${filename##*.}"
filename_no_ext="${filename%.*}"
timestamp="$(date +%Y%m%d-%H%M%S)"
filename_timestamp="${path}/${filename_no_ext}_${timestamp}.${extension}"

# Should vaoid collisions from here on down
cp $input_file "${filename_timestamp}"

tmp_file="${filename_timestamp}.tmp"
cp "${filename_timestamp}" $tmp_file

# Convert Ansible JSON output to standard JSON output

# Remove unicode string prefix "u'"
# Single -> double quotes
# False -> false
# True -> true
# None -> null # not ideal but works

cat $tmp_file \
    | sed "s/u'/'/g" \
    | sed "s/'/\"/g" \
    | sed 's/False/false/g' \
    | sed 's/True/true/g' \
    | sed 's/None/null/g' \
    >  ${filename_timestamp}

# Pretty print - assumes standard Python 2.7 installation
cp ${filename_timestamp} $tmp_file
python -m json.tool $tmp_file > ${filename_timestamp}

echo "$timestamp"
echo "${filename_timestamp}"

exit 0
