# What is this repository for? 

Ansible configuration and playbooks which provide the build and deployment system for Linux-based databroker and other services.

See README.md first for a brief summary of the essentials of the build system.

To view this file in all its glory, use some Markdown viewer or look at the content in bitbucket.

## Ansible - the bare minimum

Ansible provides automation for system deployment and configuration.

It deals with:

* *inventories* A list of the machines or _hosts_ you wish to configure and control
* *playbooks* A list of simple tasks to perform (in order) on _hosts_ listed in your _inventory_

Issuing commands

Most Ansible commands are:

  * Of the form:
  `ansible-<> -i <inventory file> <playbook>`
  * Operate on a particular _inventory_
  * Using a specific _playbook_

To override values configured appropriately in any _playbook_ specify overrides on the command-line using the form

`--extra-vars="varname1=value1 varname2=value2 ..."`

## For local development

Local Requirements on build machine ('ansible master' node):

  * A copy of this repository.
  * Ansible (and therefore python3 and pip)
  * The Ansible Vault decryption password

To build and use VMs from scratch:

  * virtualbox
  * vagrant

## Define build environment

Define the following environment variables - e.g. place in ~/.bash_profile or ~/.bashrc.

```
export ANSIBLE_BUILD_ENV=dev
export ANSIBLE_REPO_DIR=$HOME/dev/ansible
export ANSIBLE_CONFIG=${ANSIBLE_REPO_DIR}/ansible_configs/ansible_${ANSIBLE_BUILD_ENV}.cfg`
```  

## Commands

The default commands given below all assume the inventory file naming and contents structured as in './inventories/dev'.

### Virtual machine creation

**Create single Base Ubuntu VM with the ansible user configured.** 

  * Only VM configuration tool currently configured is Vagrant
  * Only VM provider currently configured is VirtualBox.
  * An inventory file is generated as 'new\_vms\_inventory.yml'

`ansible-playbook create_base_vm.yml`

**Create multiple Base Ubuntu VMs with ansible user configured.**

  * Only VM configuration tool currently configured is Vagrant
  * Only VM provider currently configured is VirtualBox.
  * An inventory file is generated as 'new\_vms\_inventory.yml'

`ansible-playbook create_base_vm.yml --extra-vars "total_vms=2"`

**AWS EC2 creation**

  * Creates a single EC2 instance
  * Can be run manually as many times as necessary.
  * An inventory file needs to be created manually.
  
`aws_create_ansible_instance`

**Export all VirtualBox VMs or a specified VM as an appliance**

`ansible-playbook export_vb_vm.yml -i new_vms_inventory.yml [ --extra-vars "vm_name=ubuntu_base_02" ]`

To access VMs from the local machine only (when created by create\_base\_vm.yml):

*Note the message in the build output*
  
`Inventory file is most recent of the form /Users/tracy.flynn/tmp/new_vms_inventory-<timestamp>`
    
This is a working inventory file for the new VMs (group 'new_vms').
  
Or manually, selecting information from inventory file:

`ssh -i $HOME/.ssh/ansible_id_rsa ansible@127.0.0.1 -p 2222`

### Configure VMs

**Bootstrapping machines into the build system**

If the VMs supplied do not already have an 'ansible' user configured:

  * Create an inventory file
  * Execute the following with appropriate parameters (all on one line).

  `ansible-playbook -i <your inventory file> ansible_user_create.yml --extra-vars="ansible_ssh_port_override='22' ansible_user_name_override='ubuntu' ansible_private_key_path_override='path to ubuntu private key file'"`


If the VMs supplied already have an standard 'ansible' user configured, update the 'ansible' user. This ensures the 'ansible' user is configured with current settings.

  * For inventory files named following the conventions in 'inventories/dev':

    `ansible_user_create`

  * For inventory files with your own file naming convention:

    `ansible-playbook -i <your inventory file> create_ansible_user.yml` 

Various keys and other credentials are encrypted. See the section below on 'Secrets and Encryption'.



### Install,  configure and manage Nginx

**Install Nginx**

  * Includes HTTPS and proxy  support - see immediately below 
  * Default group_name=nginx_hosts

`nginx_create`

`ansible-playbook nginx_create.yml -i ./inventories/${build_env}/inventory_databrokers.yml [ --extra-vars "group_name=nginx_hosts" ]`

**Install and update Nginx HTTPS Proxy support**

  * Default group_name=nginx_hosts

`nginx_manage_https_proxies`

`ansible-playbook nginx_manage_https_proxies.yml -i ./inventories/${build_env}/inventory_databrokers.yml [ --extra-vars "group_name=nginx_hosts" ]`

**Start/stop Nginx servers**
  
  * default nginx_host=nginx\_01

`nginx_start`

`ansible-playbook nginx_start.yml -i ./inventories/${build_env}/inventory_databrokers.yml [ --extra-vars"nginx_host=nginx_01" ]`

`nginx_stop`

`ansible-playbook nginx_stop.yml -i ./inventories/${build_env}/inventory_databrokers.yml [ --extra-vars "nginx_host=nginx_01" ]`

### Docker swarm management

Install Docker software

  * Installs Docker software on 'docker_managers' and 'docker_workers' nodes
  
`docker_install`

Create Docker Swarm

  * Configures all Docker nodes
  * Adds AWS CLI and credentials
  * Requires inventory organized as in './inventories/dev/inventory\_databrokers.yml'

`docker_swarm_create`

`ansible-playbook -i ./inventories/${build_env}/inventory_databrokers.yml docker_swarm_create.yml`

To deploy, update and destroy services 

  * Services are primarily defined in './inventories/\<env\>/group\_vars/docker\_managers.yml'
  * Default service is 'isodataservice'

`docker_service_create [service_name]`

`ansible-playbook -i ./inventories/${build_env}/inventory_databrokers.yml ./docker_service_create.yml   --extra-vars="service_name=${service_name}"`

`docker_service_update [service_name]`

`ansible-playbook -i ./inventories/${build_env}/inventory_databrokers.yml ./docker_service_update.yml \
  --extra-vars="service_name=${service_name}"`
  
`docker_service_remove [service_name]`

`ansible-playbook -i ./inventories/${build_env}/inventory_databrokers.yml ./docker_service_remove.yml \
  --extra-vars="service_name=${service_name}"`
  
### AWS Configuration

To configure any hosts that require AWS access:

  * All docker manager nodes need AWS to pull images from AWS ECR.
  * Default group name 'docker_managers'
  * This configuration is automatic when creating a docker swarm.

`aws_cli_install_configure`

`ansible-playbook -i ./inventories/${build_env}/inventory_databrokers.yml aws_cli_install_configure.yml`

`aws_cli_update_credentials`

`ansible-playbook -i ./inventories/${build_env}/inventory_databrokers.yml aws_cli_update_credentials.yml`

The AWS credentials are encrypted. See the section below on 'Secrets and Encryption'.

### Utilities

**Add/update ansible user**

  * Applies to all hosts in inventory by default. 
  * Can be used to fix problems with an existing ansible user.
  * Assumes ansible user and credentials are already configured.

`ansible_user_create`

`ansible-playbook -i ./inventories/${build_env}/inventory_databrokers.yml create_ansible_user.yml --extra-vars="ip_address_or_hosts=all"`

  * To create ansible user initially without inventory
  * Assumes ubuntu root credentials are configured. (See 'Secrets and Encryption' below.)

`ansible_user_create ip_address [ip_address ...]`

`ansible-playbook -i ./inventories/dev/inventory_single_ubuntu_host.yml create_ansible_user.yml --extra-vars="ip_address_or_hosts=$ip_address"`

**Add alias definitions for ansible user**

  * Replaces all alias definitions when run
  * Applies to all hosts in inventory by default. 
  * To specify specific host or group on the command line to 'ansible-playbook'
    `--extra-vars="host_or_group=inventory_host_name"`
  * See 'roles/ansible\_user/templates/bash\_aliases.j2' to see/alter alias definitions.

`ansible_user_create_aliases`

`ansible-playbook -i ./inventories/${build_env}/inventory_databrokers.yml ansible_user_create_aliases.yml`

**Add / remove users**

`user_add host_ip_address name public_key_path [sudo (default: false)] `

`ansible-playbook -i ./inventories/${build_env}/inventory_databrokers.yml user_add.yml -extra-vars="user_name=janedoe user_public_key_file=/Users/tracy.flynn/.ssh/id_rsa.pub user_sudo=true"` 

`user_del host_ip_address name`

`ansible-playbook -i ./inventories/${build_env}/inventory_databrokers.yml user_del.yml -extra-vars="user_name=janedoe"`

## Apply OS Updates & Upgrades

To automatically apply most system updates and perform a rolling upgrade on all systems. Systems will only be rebooted if required by the OS itself.

Note that this task will always skip any Grub-related updates as these may require manual intervention.

`os_update_upgrade`

`
ansible-playbook -i ./inventories/${build_env}/inventory_databrokers.yml os_update_upgrade.yml
`

## Inventory 

Inventory is one of the core features that makes Ansible work.  

Inventories are organized by environment and are self-contained within an environment. 

So, the directory 'inventories/dev' has everything needed to construct the inventories for the 'dev' environment.

To create an inventory for a new enviroment, copy the entire directory structure and contents below 'inventories/dev' into a new directory at the same level - e.g. 'inventories/myenv'. Make modifications as appropriate.

### Inventory commands

Learn the following command if you don't learn any other. To see the effective inventory that Ansible will process using a given configuration:

`ansible-inventory -i <inventory file> --list`
  
e.g. To see the dev inventory for the data broker hosts and services:

`ansible-inventory -i ./inventories/${build_env}/inventory_databrokers.yml --list`

### Inventory files

Inventory files exist at the top level of the environment-specific directory and can be named whatever way you like - to be friendly to others, use some meaningful name.

**Within an inventory file, the group and node naming conventions are significant for processing. Do not change them.**

e.g. The following examples mean something to the various scripts:

- group name: 'nginx\_hosts'
- node name: 'docker\_manager\_swarm\_primary'

Within the environment-specific directory, the layout follows the second of [Ansible's best practices organization](https://docs.ansible.com/ansible/2.6/user_guide/playbooks_best_practices.html#id12).

Of particular interest:

**'inventories/\<env\>/group\_vars/all.yml'**. This contains defaults across all groups.

A group-specific example:

  * for docker managers

`inventories/dev/group_vars/docker_managers.yml`

## Docker Network configuration

The following ports should only be open in the subnet running the Docker swarm. 

  * (TCP) Port 2376 - for secure Docker client communication
  * (TCP) port 2377 - for communication between the nodes of a Docker Swarm
  * (TCP) (UDP) Port 7946 - for communication among nodes (container network discovery)
  * (UDP) port 4789  - for overlay network traffic (container ingress networking)

## Secrets and Encryption

All 'secret' credentials are encrypted using [Ansible Vault](https://docs.ansible.com/ansible/2.6/user_guide/vault.html).

On the machine that is running the ansible playbooks two secrets are required.

**Automated secret decryption of other secrets**

Secrets are decrypted automatically when playbooks are run. 

The decryption secret password key is stored by default in '~/.ansible/.ansible\_dev.password' or the location specified in 'ansible.cfg' using the setting 'vault\_password\_file'.

  * Permission for ~/.ansible is 700 (as for ~/.ssh)
  * Permission for ~/.ansible/.ansible.vault.password is 600

Contact DevOps for information about how to obtain the decryption password.

**Install the 'standard' ansible private key locally**

`./ansible_install_PK_local`



