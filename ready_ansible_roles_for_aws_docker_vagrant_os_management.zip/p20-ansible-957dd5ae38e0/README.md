# What is this repository for? 

Ansible configuration and playbooks which provide the build system for databroker and other services.

To view this file in all its glory, use some Markdown viewer or look at the content in bitbucket.

# A summary

This document provides a brief summary of the tasks needed to create and manage the deployment of databroker and other services. See REFERENCE.md for details on all the tasks mentioned here. 

The tasks are in order starting at the point VMs have been created and the 'ansible' user installed and updated. If VMs are needed, see 'Advanced topics' at the end of this document.

The default commands given below all assume the inventory file naming and contents structured as in './inventories/dev'.

## Define build environment

Define the following environment variables - e.g. place in ~/.bash_profile or ~/.bashrc.

```
export ANSIBLE_BUILD_ENV=dev
export ANSIBLE_REPO_DIR=$HOME/dev/ansible
export ANSIBLE_CONFIG=${ANSIBLE_REPO_DIR}/ansible_configs/ansible_${ANSIBLE_BUILD_ENV}.cfg`
```

## Create appropriate inventory file

Things will go much more easily if you start by setting up an inventory file. 

See REFERENCE|Inventory organization.

##  'ansible' user

Ensure 'ansible' user is present and correctly configured.

See REFERENCE|Configure VMs, the initial section 'Bootstrapping machines into the build system'.

## Create and Manage Docker Swarm

### Install Docker software

'docker_install'

See REFERENCE|Install Docker software

### Create Docker Swarm

`docker_swarm_create`

See REFERENCE|Create Docker Swarm

### Deploy a Docker service

Assumes:

  * Docker Swarm
  * One or more Docker images in an ECR repo
  
`docker_service_create [service_name]`

See REFERENCE|To deploy, update and destroy services 

### Update and destroy a Docker service

Assumes:

  * Docker Swarm
  * One or more Docker images in an ECR repo

`docker_service_update [service_name]`

`docker_service_remove [service_name]`

See REFERENCE|To deploy, update and destroy services 

# Advanced topics

## Create VMs

See REFERENCE|Virtual machine creation

## Configure 'raw' VMs

See REFERENCE|Configure VMs

